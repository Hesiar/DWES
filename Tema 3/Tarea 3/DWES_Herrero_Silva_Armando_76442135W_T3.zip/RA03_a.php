<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RA03_a</title>
</head>
<body>
    <?php

        $edad = 20;

        if($edad >= 18) {
            echo "Eres mayor de edad";
        }else {
            echo "Eres menor de edad";
        }

    ?>
</body>
</html>