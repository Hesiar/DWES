<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Información del Alumno</title>
</head>
<body>
    <h1>Detalles del Alumno</h1>

    <?php

        $nombre = "Armando Herrero Silva";
        $dni = "76442135W";

        echo "Nombre del alumno: " . $nombre . "<br>";
        echo "NIF del alumno: " . $dni . "<br>";
        echo "El código del script PHP siempre se incluye entre las etiquetas <?php y ?>";
    ?>
</body>
</html>
