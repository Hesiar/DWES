<footer style="color: white">
    Todos los derechos reservados De rechupete 2024&copy;
</footer>