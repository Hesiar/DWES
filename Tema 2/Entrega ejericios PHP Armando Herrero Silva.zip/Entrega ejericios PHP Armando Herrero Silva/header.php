<header>
    <h1 style="color: white">De rechupete</h1>
    <h3 style="color: white">Recetas faciles y ricas con las que ser tu propio chef</h3>
</header>