<nav>
    <ul>
        <li><a href="paginaPrincipal.php">Inicio</a></li>
        <li><a href="paginaImagenes.php">Recetas</a></li>
    </ul>
</nav>