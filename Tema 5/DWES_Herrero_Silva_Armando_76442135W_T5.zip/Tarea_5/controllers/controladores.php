
<?php

    require_once 'models/modelo.php';

    class articuloController{
        
        private $modelo;
        private $sugerencias = [];
        private $usuarios = [];

        //Contructor

        public function __construct(){
            $this->modelo = new Articulos_Modelo();
        }

        //Getter

        public function listArticulos() {
            return $this->modelo->getArticulos();
            require 'view/articulos.php';
        }

        //Setter

        public function addArticulo($articulo, $precio, $stock, $categoria) {
            $this->modelo->addArticulo($articulo, $precio, $stock, $categoria);
            $this->listArticulos(); 
        }

        //Funciones

        public function ArticuloPorId($id){
            return $this->modelo->ArticuloPorId($id);
            $this->listArticulos(); 
        }

        // Métodos de Sugerencias
        public function listSugerencias() {
            $sugerencias = $this->sugerencias;
            require 'view/sugerencias.php';
        }

        public function addSugerencia($texto) {
            $this->sugerencias[] = $texto;
            $this->listSugerencias();
        }

        // Métodos de Registro
        public function showFormRegistro() {
            require 'view/registro.php';
        }

        public function registrarUsuario($nombre, $email) {
            $this->usuarios[] = ['nombre' => $nombre, 'email' => $email];
            echo "<p>Usuario registrado: $nombre ($email)</p>";
            echo '<a href="index.php?action=registro">Volver al registro</a>';
        }
    }    
?>