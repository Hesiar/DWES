
<?php

    if (!defined('CON_CONTROLADOR')) {
        die('Error: No se puede acceder directamente a este archivo.');
    }

    class Articulos_Modelo{

    private $articulos = [];

        //Constructor

        public function __construct() {
            $this->articulos = [
                ['id' => 1, 'nombre' => 'Detector de humo', 'precio' => 10.99, 'stock' => 10, 'categoria' => 'Electronica'],
                ['id' => 2, 'nombre' => 'Lampara de escritorio', 'precio' => 5.99, 'stock' => 0, 'categoria' => 'Electronica'],
                ['id' => 3, 'nombre' => 'Caja de herramientas', 'precio' => 29.99, 'stock' => 15, 'categoria' => 'Herramientas'],
            ];
        }

        //Getter

        public function getArticulos() {
            return $this->articulos;
        }

        //Setter(Add)

        public function addArticulo($articulo, $precio, $stock, $categoria) {
            $id = count($this->articulos) + 1;
            $this->articulos[] = ['id' => $id, 'nombre' => $articulo, 'precio' => $precio, 'stock' => $stock, 'categoria' => $categoria];
        }

        //Funciones

        public function ArticuloPorId($id){
            foreach ($this->articulos as $articulo) {
                if ($articulo['id'] == $id) {
                    return $articulo;
                }
            }
            return null;
        }
    }
?>