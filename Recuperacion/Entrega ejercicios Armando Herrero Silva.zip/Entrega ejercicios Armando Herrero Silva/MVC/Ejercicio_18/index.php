<?php
    require_once 'controlador/ControladorComentario.php';
    $controlador = new ControladorComentario();
    $controlador->mostrarComentarios();
?>  