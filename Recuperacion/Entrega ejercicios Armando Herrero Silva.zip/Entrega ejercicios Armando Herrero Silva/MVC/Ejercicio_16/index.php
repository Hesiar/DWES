<?php
    require_once 'ControladorUsuario.php';

    $controlador = new ControladorUsuario();
    $controlador->mostrarUsuarios();    
?>