<?php
    require_once 'ControladorProducto.php';
    $controlador = new ControladorProducto();
    $controlador->mostrarProductos();
?>  