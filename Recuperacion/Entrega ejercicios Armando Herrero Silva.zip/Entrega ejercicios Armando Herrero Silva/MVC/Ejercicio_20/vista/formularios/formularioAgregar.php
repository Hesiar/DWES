<form action="index.php?accion=agregar" method="post">
    <input type="text" name="descripcion" placeholder="Descripción de la tarea" required>
    <button type="submit">Agregar</button>
</form>
