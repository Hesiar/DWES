<form action="index.php?accion=eliminar" method="post">
    <input type="hidden" name="id" value="<?php echo $tarea['id']; ?>">
    <button type="submit">Eliminar</button>
</form>
