<?php
    require_once 'controlador/ControladorTarea.php';
    $controlador = new ControladorTarea();
    $controlador->listarTareas();
?>
